# Changelog

## 0.2.0
- Estado central reativo do aplicativo
- Cadastro de jogador
- Criação de partida
- Scout ao vivo completo para eventos básicos
- Controle de quinteto em quadra
- Desfazer evento
- Encerramento de partida
- Box score real para partidas registradas
- Eventos associados ao lineup em quadra
- Primeira geração de Lineup Analytics a partir do scout
- Motor de insights dinâmico
- Pós-jogo com métricas calculadas
- Home/Analytics/Insights ligados ao jogo mais recente

## 0.1.0
- Protótipo visual inicial
- Dados simulados
- Métricas analíticas básicas
- Estrutura de navegação
