import 'package:flutter/widgets.dart';
import '../data/mock_repository.dart';
import '../models/game.dart';
import '../models/live_game_session.dart';
import '../models/play_event.dart';
import '../models/player.dart';

class AppState extends ChangeNotifier {
  final List<Player> players = [...MockRepository.players];
  final List<Game> games = [...MockRepository.games];
  LiveGameSession? activeGame;

  void addPlayer({required String name, required String position, required int number}) {
    players.add(Player(
      id: 'p${DateTime.now().microsecondsSinceEpoch}',
      name: name,
      position: position,
      number: number,
    ));
    notifyListeners();
  }

  bool startGame(String opponent) {
    if (opponent.trim().isEmpty || players.length < 5) return false;
    final starters = players.take(5).map((p) => p.id).toList();
    activeGame = LiveGameSession(
      opponent: opponent.trim(),
      startedAt: DateTime.now(),
      lineupIds: starters,
      selectedPlayerId: starters.first,
    );
    notifyListeners();
    return true;
  }

  void selectPlayer(String playerId) {
    final game = activeGame;
    if (game == null) return;
    game.selectedPlayerId = playerId;
    notifyListeners();
  }

  void setPeriod(int period) {
    final game = activeGame;
    if (game == null) return;
    game.period = period < 1 ? 1 : (period > 4 ? 4 : period);
    notifyListeners();
  }

  void changeLineup(String playerId, bool onCourt) {
    final game = activeGame;
    if (game == null) return;
    if (onCourt) {
      if (game.lineupIds.length >= 5 || game.lineupIds.contains(playerId)) return;
      game.lineupIds.add(playerId);
    } else {
      game.lineupIds.remove(playerId);
      if (game.selectedPlayerId == playerId) {
        game.selectedPlayerId = game.lineupIds.isEmpty ? null : game.lineupIds.first;
      }
    }
    notifyListeners();
  }

  void addEvent(PlayEventType type, {String? playerId}) {
    final game = activeGame;
    if (game == null || game.finished) return;
    final id = playerId ?? game.selectedPlayerId;

    if (type == PlayEventType.opponentOne ||
        type == PlayEventType.opponentTwo ||
        type == PlayEventType.opponentThree) {
      final points = type == PlayEventType.opponentOne ? 1 : (type == PlayEventType.opponentTwo ? 2 : 3);
      game.opponentScore += points;
      game.events.add(PlayEvent(type: type, period: game.period, timestamp: DateTime.now(), lineupIds: List<String>.from(game.lineupIds)));
      notifyListeners();
      return;
    }

    if (id == null) return;
    final stat = game.playerStats.putIfAbsent(id, PlayerGameStats.new);
    switch (type) {
      case PlayEventType.twoMade:
        stat.points += 2; stat.fgm++; stat.fga++; game.ourScore += 2;
        break;
      case PlayEventType.twoMiss:
        stat.fga++;
        break;
      case PlayEventType.threeMade:
        stat.points += 3; stat.fgm++; stat.fga++; stat.threePm++; stat.threePa++; game.ourScore += 3;
        break;
      case PlayEventType.threeMiss:
        stat.fga++; stat.threePa++;
        break;
      case PlayEventType.freeThrowMade:
        stat.points++; stat.ftm++; stat.fta++; game.ourScore++;
        break;
      case PlayEventType.freeThrowMiss:
        stat.fta++;
        break;
      case PlayEventType.assist:
        stat.assists++;
        break;
      case PlayEventType.offensiveRebound:
        stat.offensiveRebounds++;
        break;
      case PlayEventType.defensiveRebound:
        stat.defensiveRebounds++;
        break;
      case PlayEventType.steal:
        stat.steals++;
        break;
      case PlayEventType.block:
        stat.blocks++;
        break;
      case PlayEventType.turnover:
        stat.turnovers++;
        break;
      case PlayEventType.foul:
        stat.fouls++;
        break;
      case PlayEventType.opponentOne:
      case PlayEventType.opponentTwo:
      case PlayEventType.opponentThree:
        break;
    }
    game.events.add(PlayEvent(type: type, playerId: id, period: game.period, timestamp: DateTime.now(), lineupIds: List<String>.from(game.lineupIds)));
    notifyListeners();
  }

  void undoLastEvent() {
    final game = activeGame;
    if (game == null || game.events.isEmpty) return;
    final event = game.events.removeLast();
    _reverseEvent(game, event);
    notifyListeners();
  }

  void _reverseEvent(LiveGameSession game, PlayEvent event) {
    if (event.type == PlayEventType.opponentOne || event.type == PlayEventType.opponentTwo || event.type == PlayEventType.opponentThree) {
      game.opponentScore -= event.type == PlayEventType.opponentOne ? 1 : (event.type == PlayEventType.opponentTwo ? 2 : 3);
      return;
    }
    final stat = game.playerStats[event.playerId];
    if (stat == null) return;
    switch (event.type) {
      case PlayEventType.twoMade:
        stat.points -= 2; stat.fgm--; stat.fga--; game.ourScore -= 2;
        break;
      case PlayEventType.twoMiss:
        stat.fga--;
        break;
      case PlayEventType.threeMade:
        stat.points -= 3; stat.fgm--; stat.fga--; stat.threePm--; stat.threePa--; game.ourScore -= 3;
        break;
      case PlayEventType.threeMiss:
        stat.fga--; stat.threePa--;
        break;
      case PlayEventType.freeThrowMade:
        stat.points--; stat.ftm--; stat.fta--; game.ourScore--;
        break;
      case PlayEventType.freeThrowMiss:
        stat.fta--;
        break;
      case PlayEventType.assist:
        stat.assists--;
        break;
      case PlayEventType.offensiveRebound:
        stat.offensiveRebounds--;
        break;
      case PlayEventType.defensiveRebound:
        stat.defensiveRebounds--;
        break;
      case PlayEventType.steal:
        stat.steals--;
        break;
      case PlayEventType.block:
        stat.blocks--;
        break;
      case PlayEventType.turnover:
        stat.turnovers--;
        break;
      case PlayEventType.foul:
        stat.fouls--;
        break;
      case PlayEventType.opponentOne:
      case PlayEventType.opponentTwo:
      case PlayEventType.opponentThree:
        break;
    }
  }

  Game? finishGame() {
    final live = activeGame;
    if (live == null) return null;
    live.finished = true;
    final possessions = live.estimatedPossessions.round().clamp(1, 999) as int;
    final statLines = <String, PlayerStatLine>{
      for (final entry in live.playerStats.entries)
        entry.key: PlayerStatLine(
          points: entry.value.points,
          assists: entry.value.assists,
          offensiveRebounds: entry.value.offensiveRebounds,
          defensiveRebounds: entry.value.defensiveRebounds,
          steals: entry.value.steals,
          blocks: entry.value.blocks,
          turnovers: entry.value.turnovers,
          fouls: entry.value.fouls,
          fgm: entry.value.fgm,
          fga: entry.value.fga,
          threePm: entry.value.threePm,
          threePa: entry.value.threePa,
          ftm: entry.value.ftm,
          fta: entry.value.fta,
        ),
    };
    final game = Game(
      opponent: live.opponent,
      date: live.startedAt,
      ourScore: live.ourScore,
      opponentScore: live.opponentScore,
      possessions: possessions,
      fgm: live.fgm,
      fga: live.fga,
      threePm: live.threePm,
      threePa: live.threePa,
      ftm: live.ftm,
      fta: live.fta,
      turnovers: live.turnovers,
      offensiveRebounds: live.offensiveRebounds,
      availableOffensiveRebounds: (live.fga - live.fgm + live.offensiveRebounds).clamp(1, 999) as int,
      opponentPoints: live.opponentScore,
      playerStats: statLines,
      events: List<PlayEvent>.from(live.events),
    );
    games.insert(0, game);
    activeGame = null;
    notifyListeners();
    return game;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({Key? key, required AppState state, required Widget child}) : super(key: key, notifier: state, child: child);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found');
    return scope!.notifier!;
  }
}
