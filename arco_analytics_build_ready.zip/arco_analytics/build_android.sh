#!/usr/bin/env bash
set -euo pipefail
flutter create . --platforms=android --org com.arcoanalytics
flutter pub get
flutter analyze
flutter build apk --release
printf '\nAPK gerado em:\n%s\n' "$(pwd)/build/app/outputs/flutter-apk/app-release.apk"
