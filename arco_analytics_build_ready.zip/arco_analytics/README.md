# ARCO Analytics — MVP v0.2

Plataforma Flutter para análise estatística e tomada de decisão no basquete, inspirada na lógica de encontrar **vantagens competitivas escondidas nos dados**.

## Filosofia do produto

**Dado → Contexto → Insight → Decisão**

O ARCO não deve ser apenas um box score. O objetivo é mostrar ao treinador quais fatores, atletas e combinações aumentam ou reduzem a eficiência da equipe.

## O que funciona nesta versão

### Fluxo de jogo
- Cadastro de novos jogadores
- Criação de nova partida
- Scout ao vivo
- Seleção do atleta responsável pela ação
- Controle do quinteto que está em quadra
- Registro de 2PT, 3PT e lance livre convertido/errado
- Assistência
- Rebote ofensivo e defensivo
- Roubo
- Toco
- Turnover
- Falta
- Pontuação do adversário
- Troca de período
- Desfazer último evento
- Encerrar e salvar a partida na sessão atual

### Analytics automáticos
- eFG%
- TS%
- Offensive Rating
- Defensive Rating
- Net Rating
- TOV%
- ORB%
- FT Rate
- On/Off de jogadores da base demonstrativa
- ARCO Impact Score experimental
- Confiança de amostra por número de posses
- Four Factors

### Moneyball / Lineup Analytics
Cada evento do scout guarda o quinteto que estava em quadra. Ao encerrar uma partida, o ARCO consegue agrupar ações por formação e criar uma primeira estimativa de:
- posses por lineup
- Offensive Rating por lineup
- Defensive Rating por lineup
- Net Rating por lineup
- nível de confiança da amostra

### Motor de insights
O MVP já gera conclusões automáticas baseadas em:
- turnovers
- eficiência de arremesso
- ritmo de jogo
- vitórias/derrotas
- impacto On/Off
- lineups

Os insights sempre carregam evidência numérica e, quando aplicável, indicação de tamanho da amostra.

### Pós-jogo
Partidas registradas pelo scout exibem:
- placar
- métricas principais
- leitura automática do ARCO
- box score registrado
- lineups capturados
- Four Factors disponíveis

## Telas
- Home / Central de decisão
- Jogos
- Nova partida
- Scout ao vivo
- Pós-jogo
- Equipe
- Perfil individual
- Analytics
- Insights
- Scout do adversário
- Game Plan
- Relatórios

## Dados de demonstração
O projeto ainda carrega dados simulados de temporada em `lib/data/mock_repository.dart` para que o app tenha conteúdo antes de existir uma base persistente.

Quando uma nova partida é registrada pelo scout, o jogo real criado na sessão passa a ocupar o topo do histórico e alimenta Home, Analytics e Insights.

## Limitações atuais importantes

1. Os dados ainda ficam **somente em memória**. Ao fechar o app, as novas partidas não são persistidas.
2. O shot chart exibido ainda é demonstrativo; o próximo passo é registrar coordenadas reais de cada arremesso.
3. O cálculo de posses por lineup é uma primeira estimativa baseada nos eventos registrados. Para nível profissional, o possession engine será refinado.
4. O ARCO Impact Score ainda é experimental e precisa ser calibrado em uma base histórica antes de ser tratado como indicador oficial.
5. O scout do adversário e o Game Plan ainda são telas de estrutura/demonstração.

## Como abrir

Este pacote contém o código-fonte Flutter. Em uma máquina com Flutter 3.19+ / Dart 3.3+:

```bash
flutter create .
flutter pub get
flutter run
```

`flutter create .` gera as pastas Android/iOS/Web caso elas ainda não existam, preservando o conteúdo de `lib/` e o `pubspec.yaml`.

## Próxima versão planejada — v0.3

- banco local/persistência
- temporadas e múltiplas equipes
- shot chart interativo com coordenadas
- relógio/minutagem
- substituições com tempo de quadra
- possession engine refinado
- duplas e trios
- splits por quarto
- clutch
- tendências por janela de jogos
- relatório PDF

## Regra de produto

**Nenhum insight deve ser apresentado como certeza sem contexto e amostra suficiente.**

## Gerar APK Android

Este repositório inclui duas formas de gerar o APK:

1. Localmente, com Flutter instalado: execute `./build_android.sh`.
2. No GitHub Actions: envie o projeto para um repositório, abra **Actions > Build Android APK > Run workflow** e baixe o artefato `arco-analytics-apk` ao final.

O arquivo gerado será `app-release.apk`.
